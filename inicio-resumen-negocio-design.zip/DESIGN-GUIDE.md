# Guía de diseño — Inicio: Resumen del negocio

> **URL original:** https://app.alegra.com/ (ítem "Inicio" del sidebar)
> **Extraído con:** extract-design (SingleFile + captura en vivo + CSS)

## Qué contiene este paquete

| Archivo | Qué es |
|---|---|
| `screenshot.png` | Dashboard completo capturado EN VIVO (1400×2200), con todos los widgets |
| `screenshot-estados-vacios.png` | Estados vacíos de los widgets ("Sin ventas registradas") |
| `page.html` | Página autocontenida (SingleFile) — incluye el shell + tarjetas KPI |
| `page-live.html` | DOM vivo completo — incluye los widgets de gráficas que cargan tarde |
| `styles.css` | Todo el CSS extraído y formateado |
| `DESIGN-GUIDE.md` | Este documento |

**Nota:** SingleFile no alcanzó a capturar los widgets de gráficas (cargan diferido). Por eso el screenshot se tomó sobre la página en vivo y se incluye `page-live.html` con el DOM completo de todos los widgets.

## Estructura de la página

- **Sin breadcrumb** (a diferencia de los reportes). Solo el título `Resumen del negocio` (H1, peso semibold).
- **Acciones arriba a la derecha:** chip filtro `Mes actual ▾` + botón `Agregar gráfica ▾` (teal claro).
- El contenido es una **grilla de widgets/cards** que el usuario puede agregar/quitar (cada card tiene menú ⋮ con opciones de expandir/eliminar).

### Widgets del dashboard (de arriba abajo)

1. **Fila de tarjetas KPI** (grid):
   - **Cuentas por cobrar** (card grande): monto `RD$7,871.00` + barra de progreso teal→rojo + desglose `Vigentes` (verde) / `Vencidas` (rojo) con montos y nº de documentos.
   - **Cuentas por pagar** (card grande): mismo patrón.
   - **Cards pequeñas** (2×2): `Impuestos en venta`, `Clientes con ventas`, `Devoluciones de clientes` (con sub-nota "Incluye impuestos"), `Productos vendidos`. Título con link subrayado + valor grande.
2. **Total de ventas** (card ancha): label + tooltip `ⓘ`, subtítulo, total a la derecha `RD$21,009.60` + `%` variación. Gráfica de **línea** diaria (línea azul del período actual, punteada teal del anterior), leyenda con rango de fechas.
3. **Distribución de gastos** (card ancha): **donut chart** con total centrado (`RD$2,630.00`) + tabla lateral `Concepto | Valor | Participación` con dot de color por fila (rojo/azul/verde/amarillo).
4. **Flujo de transacciones** (card ancha): dos totales arriba (`Total ingresos`, `Total egresos` + `%`) + **barras** verde (ingresos) / roja (egresos) por fecha.
5. **Fila de dos tablas** (grid 2 col): `Productos más vendidos` (avatar iniciales + Concepto | Nº items | Total vendido) y `Mejores clientes` (Concepto | Nº documentos | Total vendido).
6. **Estado vacío** de widget: ícono de gráfica gris + `Sin ventas registradas` + subtítulo explicativo.
7. Widgets opcionales vía "Agregar gráfica" (p. ej. `Bancos y cajas`).

## Sistema de diseño

- **Framework:** Tailwind CSS scopado (`.ac-tailwind`, app AngularJS + Next). Fuente `Inter, Roboto, sans-serif`.
- **Primario teal Alegra:** `#30aba9` (escala `--sm-color-primary-50..900`); botón "Agregar gráfica" en teal-50/100 con texto teal-700.
- **Gráficas:** librería tipo Chart.js/AmCharts — línea azul `#3b5bdb`-like, barras verde `#34d399` / roja `#ef4444`, donut multicolor (rojo `#ef4444`, azul `#3b82f6`, verde `#10b981`, amarillo `#f59e0b`).
- **Cards:** `bg-white rounded-xl border border-slate-200 p-4 shadow-sm`.
- **Texto:** principal `#0f172a`/`#334155`, secundario `#64748b`, montos en semibold con moneda `RD$`.
- **Estados:** verde `#22c55e`/`#34d399` (vigente/ingreso), rojo `#e11d48`/`#ef4444` (vencido/egreso).

## Cómo reproducirlo (Tailwind/shadcn)

```html
<!-- Card KPI grande -->
<div class="rounded-xl border border-slate-200 bg-white p-4">
  <a class="text-sm font-medium underline">Cuentas por cobrar</a>
  <p class="text-2xl font-semibold">RD$7,871.00</p>
  <div class="h-1.5 rounded-full bg-gradient-to-r from-emerald-400 to-red-400"></div>
  <!-- split Vigentes | Vencidas con borde lateral verde/rojo -->
</div>
<!-- Card de gráfica -->
<div class="rounded-xl border border-slate-200 bg-white p-4">
  <div class="flex justify-between"><h3 class="font-semibold">Total de ventas</h3><p class="text-xl font-semibold">RD$21,009.60</p></div>
</div>
<!-- Botón secundario teal -->
<button class="rounded-lg bg-teal-50 px-4 py-2 text-sm font-medium text-teal-700">Agregar gráfica ▾</button>
```

## Notas

- `styles.css` incluye el bundle completo del shell (sidebar, header, modales, datepickers).
- Los widgets responden al período del chip `Mes actual`; con pocos datos muestran el empty state.
